package com.example.ridesharebooks.data.local
import android.content.Context
import androidx.room.*
import com.example.ridesharebooks.data.local.entities.*
@Database(entities=[EarningEntity::class,ExpenseEntity::class,OdometerEntity::class,SettingEntity::class],version=1,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){abstract fun earningDao():EarningDao;abstract fun expenseDao():ExpenseDao;abstract fun odometerDao():OdometerDao
companion object{ @Volatile private var i:AppDatabase?=null; fun getDatabase(c:Context)=i?:synchronized(this){i?:Room.databaseBuilder(c.applicationContext,AppDatabase::class.java,"rideshare_books_database").build().also{i=it}}}}
