package com.example.ridesharebooks.data.local
import androidx.room.*
import com.example.ridesharebooks.data.local.entities.*
import kotlinx.coroutines.flow.Flow
@Dao interface EarningDao{@Query("SELECT * FROM earnings ORDER BY dateMillis DESC") fun all():Flow<List<EarningEntity>>;@Insert suspend fun insert(x:EarningEntity);@Delete suspend fun delete(x:EarningEntity)}
@Dao interface ExpenseDao{@Query("SELECT * FROM expenses ORDER BY dateMillis DESC") fun all():Flow<List<ExpenseEntity>>;@Insert suspend fun insert(x:ExpenseEntity);@Delete suspend fun delete(x:ExpenseEntity)}
@Dao interface OdometerDao{@Query("SELECT * FROM odometer_logs ORDER BY dateMillis DESC") fun all():Flow<List<OdometerEntity>>;@Insert suspend fun insert(x:OdometerEntity);@Delete suspend fun delete(x:OdometerEntity)}
