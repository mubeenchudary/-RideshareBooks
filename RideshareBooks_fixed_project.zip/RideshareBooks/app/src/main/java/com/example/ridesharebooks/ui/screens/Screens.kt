package com.example.ridesharebooks.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ridesharebooks.ui.MainViewModel
@Composable fun DashboardScreen(vm:MainViewModel){val s by vm.summary.collectAsState();Column(Modifier.padding(16.dp)){Text("Financial Overview",style=MaterialTheme.typography.titleLarge);Text("Earnings: $%.2f".format(s.earnings));Text("Expenses: $%.2f".format(s.expenses));Text("Net Income: $%.2f".format(s.earnings-s.expenses));Text("GST/HST Collected: $%.2f".format(s.gstCollected));Text("GST/HST Paid: $%.2f".format(s.gstPaid));Text("Business Distance: %.1f km".format(s.businessKm))}}
@Composable fun EarningsScreen(vm:MainViewModel){var f by remember{mutableStateOf("")};var t by remember{mutableStateOf("")};Column(Modifier.padding(16.dp)){Text("Earnings",style=MaterialTheme.typography.titleLarge);OutlinedTextField(f,{f=it},label={Text("Fare")});OutlinedTextField(t,{t=it},label={Text("Tips")});Button(onClick={vm.addEarning("Uber",f.toDoubleOrNull()?:0.0,t.toDoubleOrNull()?:0.0,0.0,0.0);f="";t=""}){Text("Save")}}}
@Composable fun ExpensesScreen(vm:MainViewModel){var a by remember{mutableStateOf("")};var g by remember{mutableStateOf("")};Column(Modifier.padding(16.dp)){Text("Expenses",style=MaterialTheme.typography.titleLarge);OutlinedTextField(a,{a=it},label={Text("Amount")});OutlinedTextField(g,{g=it},label={Text("GST/HST Paid")});Button(onClick={vm.addExpense("Fuel",a.toDoubleOrNull()?:0.0,g.toDoubleOrNull()?:0.0);a="";g=""}){Text("Save")}}}
@Composable fun OdometerScreen(vm:MainViewModel){var s by remember{mutableStateOf("")};var e by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};Column(Modifier.padding(16.dp)){Text("Mileage",style=MaterialTheme.typography.titleLarge);OutlinedTextField(s,{s=it},label={Text("Start")});OutlinedTextField(e,{e=it},label={Text("End")});OutlinedTextField(p,{p=it},label={Text("Personal km")});Button(onClick={vm.addOdometer(s.toDoubleOrNull()?:0.0,e.toDoubleOrNull()?:0.0,p.toDoubleOrNull()?:0.0)}){Text("Log Trip")}}}
@Composable fun SettingsScreen(){Column(Modifier.padding(16.dp)){Text("Settings",style=MaterialTheme.typography.titleLarge);Text("Backup and export can be added in the next build step.")}}
