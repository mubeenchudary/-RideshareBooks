package com.example.ridesharebooks.ui.theme
import androidx.compose.ui.graphics.Color
val PrimaryBlue=Color(0xFF0F52BA);val SecondaryGreen=Color(0xFF2E7D32);val AccentOrange=Color(0xFFE65100)
