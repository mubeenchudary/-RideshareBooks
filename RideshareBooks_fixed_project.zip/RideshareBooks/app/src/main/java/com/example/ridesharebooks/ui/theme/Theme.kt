package com.example.ridesharebooks.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
private val Light=lightColorScheme(primary=PrimaryBlue,secondary=SecondaryGreen,tertiary=AccentOrange)
@Composable fun RideshareBooksTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=Light,content=content)}
