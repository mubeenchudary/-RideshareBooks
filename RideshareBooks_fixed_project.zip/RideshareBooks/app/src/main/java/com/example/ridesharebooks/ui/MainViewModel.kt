package com.example.ridesharebooks.ui
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ridesharebooks.data.local.AppDatabase
import com.example.ridesharebooks.data.local.entities.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
data class DashboardSummary(val earnings:Double=0.0,val expenses:Double=0.0,val businessKm:Double=0.0,val gstCollected:Double=0.0,val gstPaid:Double=0.0)
class MainViewModel(a:Application):AndroidViewModel(a){private val d=AppDatabase.getDatabase(a);val earnings=d.earningDao().all().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val expenses=d.expenseDao().all().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val odometer=d.odometerDao().all().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val summary=combine(earnings,expenses,odometer){e,x,o->DashboardSummary(e.sumOf{it.netFare+it.tips+it.bonuses},x.sumOf{it.amount},o.sumOf{it.businessKm},e.sumOf{it.gstHstCollected},x.sumOf{it.gstHstPaid})}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),DashboardSummary())
fun addEarning(p:String,f:Double,t:Double,b:Double,g:Double)=viewModelScope.launch{d.earningDao().insert(EarningEntity(platform=p,dateMillis=System.currentTimeMillis(),netFare=f,tips=t,bonuses=b,gstHstCollected=g))}
fun addExpense(c:String,a:Double,g:Double)=viewModelScope.launch{d.expenseDao().insert(ExpenseEntity(category=c,amount=a,gstHstPaid=g,dateMillis=System.currentTimeMillis()))}
fun addOdometer(s:Double,e:Double,p:Double)=viewModelScope.launch{val total=(e-s).coerceAtLeast(0.0);d.odometerDao().insert(OdometerEntity(dateMillis=System.currentTimeMillis(),startKm=s,endKm=e,businessKm=(total-p).coerceAtLeast(0.0),personalKm=p.coerceAtLeast(0.0)))} }
