package com.example.ridesharebooks.data.local.entities
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName="earnings") data class EarningEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val platform:String,val dateMillis:Long,val netFare:Double,val tips:Double,val bonuses:Double,val gstHstCollected:Double,val notes:String="")
@Entity(tableName="expenses") data class ExpenseEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val category:String,val amount:Double,val gstHstPaid:Double,val dateMillis:Long,val note:String="",val receiptPhotoPath:String?=null)
@Entity(tableName="odometer_logs") data class OdometerEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val dateMillis:Long,val startKm:Double,val endKm:Double,val businessKm:Double,val personalKm:Double,val notes:String="")
@Entity(tableName="app_settings") data class SettingEntity(@PrimaryKey val key:String,val value:String)
