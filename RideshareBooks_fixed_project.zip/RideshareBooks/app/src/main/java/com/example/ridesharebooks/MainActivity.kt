package com.example.ridesharebooks
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.ridesharebooks.ui.MainViewModel
import com.example.ridesharebooks.ui.navigation.NavGraph
import com.example.ridesharebooks.ui.theme.RideshareBooksTheme
class MainActivity:ComponentActivity(){ private val vm:MainViewModel by viewModels(); override fun onCreate(b:Bundle?){super.onCreate(b);setContent{RideshareBooksTheme{NavGraph(vm)}}}}
