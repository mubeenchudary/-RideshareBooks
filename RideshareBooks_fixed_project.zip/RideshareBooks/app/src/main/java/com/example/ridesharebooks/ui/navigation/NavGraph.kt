package com.example.ridesharebooks.ui.navigation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.example.ridesharebooks.ui.MainViewModel
import com.example.ridesharebooks.ui.screens.*
@Composable fun NavGraph(vm:MainViewModel){val n=rememberNavController();Scaffold(topBar={TopAppBar(title={Text("Rideshare Books")})},bottomBar={NavigationBar{listOf("Home","Earnings","Expenses","Mileage","Settings").forEachIndexed{i,s->NavigationBarItem(selected=false,onClick={n.navigate(listOf("home","earnings","expenses","mileage","settings")[i])},icon={},label={Text(s)})}}}){p->NavHost(n,"home",Modifier.padding(p)){composable("home"){DashboardScreen(vm)};composable("earnings"){EarningsScreen(vm)};composable("expenses"){ExpensesScreen(vm)};composable("mileage"){OdometerScreen(vm)};composable("settings"){SettingsScreen()}}}}
